import pygame
import random
import sys
from math import sin, cos, radians, sqrt

# Inicialização
pygame.init()
LARGURA, ALTURA = 800, 600
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Naruto Lego: Batalha Ninja")

# Cores
PRETO = (0, 0, 0)
BRANCO = (255, 255, 255)
LARANJA = (255, 165, 0)
AZUL = (30, 144, 255)
VERMELHO = (255, 0, 0)
VERDE = (34, 139, 34)
CINZA = (128, 128, 128)
MARROM = (139, 69, 19)
AMARELO = (255, 255, 0)
VERMELHO_BRILHANTE = (255, 50, 50)

# Classe para animação suave
class Animador:
    def __init__(self, alvo):
        self.alvo = alvo
        self.pos_alvo = [alvo.x, alvo.y]
        self.pos_atual = [alvo.x, alvo.y]
        self.suavizacao = 0.2

    def atualizar(self):
        self.pos_atual[0] += (self.pos_alvo[0] - self.pos_atual[0]) * self.suavizacao
        self.pos_atual[1] += (self.pos_alvo[1] - self.pos_atual[1]) * self.suavizacao
        self.alvo.x, self.alvo.y = self.pos_atual

    def definir_alvo(self, x, y):
        self.pos_alvo = [x, y]

# Classe Jogador
class Jogador:
    def __init__(self):
        self.x = LARGURA // 2
        self.y = ALTURA // 2
        self.velocidade = 10
        self.facing_right = True
        self.animador = Animador(self)
        self.shurikens = []
        self.cooldown = 0
        self.ultima_direcao = "direita"
        self.frame_animacao = 0
        self.timer_animacao = 0
        self.transformado = False
        self.tempo_transformacao = 0
        self.angulo_transformacao = 0

    def mover(self, teclas):
        moved = False
        # Controles de movimento com SETAS e WASD
        if teclas[pygame.K_LEFT] or teclas[pygame.K_a]:
            self.x -= self.velocidade
            self.facing_right = False
            moved = True
        if teclas[pygame.K_RIGHT] or teclas[pygame.K_d]:
            self.x += self.velocidade
            self.facing_right = True
            moved = True
        if teclas[pygame.K_UP] or teclas[pygame.K_w]:
            self.y -= self.velocidade
            moved = True
        if teclas[pygame.K_DOWN] or teclas[pygame.K_s]:
            self.y += self.velocidade
            moved = True

        if moved:
            self.animador.definir_alvo(self.x, self.y)
            self.timer_animacao += 1
            if self.timer_animacao >= 10:
                self.timer_animacao = 0
                self.frame_animacao = 1 - self.frame_animacao

        self.x = max(30, min(LARGURA - 30, self.x))
        self.y = max(30, min(ALTURA - 30, self.y))

    def atirar_shuriken(self, direcao):
        if self.cooldown == 0 and not self.transformado:
            velocidades = {
                "cima": (0, -15),
                "baixo": (0, 15),
                "esquerda": (-15, 0),
                "direita": (15, 0)
            }
            velx, vely = velocidades[direcao]
            self.shurikens.append({
                'x': self.x,
                'y': self.y,
                'velx': velx,
                'vely': vely,
                'frame': 0
            })
            self.cooldown = 15
            self.ultima_direcao = direcao

    def transformar(self):
        self.transformado = True
        self.tempo_transformacao = 10 * 60
        self.velocidade = 15

    def atualizar_transformacao(self):
        if self.transformado:
            self.tempo_transformacao -= 1
            self.angulo_transformacao += 5
            if self.tempo_transformacao <= 0:
                self.transformado = False
                self.velocidade = 10
                self.angulo_transformacao = 0

    def desenhar(self):
        self.animador.atualizar()
        
        if self.transformado:
            tamanho = 40
            pontos = []
            for i in range(4):
                ang = radians(self.angulo_transformacao + i * 90)
                pontos.append((
                    self.x + tamanho * cos(ang),
                    self.y + tamanho * sin(ang)
                ))
            pygame.draw.polygon(tela, VERMELHO_BRILHANTE, pontos)
            
            s = pygame.Surface((LARGURA, ALTURA), pygame.SRCALPHA)
            s.fill((255, 50, 50, 30))
            tela.blit(s, (0, 0))
        else:
            cor = AZUL
            pygame.draw.rect(tela, cor, (self.x - 20, self.y - 15, 40, 30))
            pygame.draw.circle(tela, LARANJA, (self.x, self.y - 20), 10)
            pygame.draw.rect(tela, VERMELHO, (self.x - 10, self.y - 25, 20, 3))

# Classe InimigoNinja
class InimigoNinja:
    def __init__(self):
        lado = random.choice(['esquerda', 'direita', 'topo', 'base'])
        posicoes = {
            'esquerda': (0, random.randint(100, ALTURA-100)),
            'direita': (LARGURA, random.randint(100, ALTURA-100)),
            'topo': (random.randint(100, LARGURA-100), 0),
            'base': (random.randint(100, LARGURA-100), ALTURA)
        }
        self.x, self.y = posicoes[lado]
        self.velocidade = random.uniform(1.0, 2.0)
        self.tamanho = 25
        self.vida = 2
        self.removido = False

    def mover(self, jogador_x, jogador_y):
        dx = jogador_x - self.x
        dy = jogador_y - self.y
        distancia = max(1, sqrt(dx**2 + dy**2))
        self.x += dx / distancia * self.velocidade
        self.y += dy / distancia * self.velocidade

    def desenhar(self):
        pygame.draw.circle(tela, CINZA, (int(self.x), int(self.y)), self.tamanho)
        pygame.draw.rect(tela, VERMELHO, (self.x - 15, self.y - 20, 30, 5))

# Classe Cenario
class Cenario:
    def __init__(self):
        self.noite = False
        self.cor_ceu = (135, 206, 235)
        self.cor_montanhas = (0, 80, 0)

    def mudar_para_noite(self):
        self.noite = True
        self.cor_ceu = (20, 20, 50)
        self.cor_montanhas = (0, 30, 0)

    def voltar_dia(self):
        self.noite = False
        self.cor_ceu = (135, 206, 235)
        self.cor_montanhas = (0, 80, 0)

    def desenhar(self):
        pygame.draw.rect(tela, self.cor_ceu, (0, 0, LARGURA, ALTURA))
        pygame.draw.rect(tela, VERDE, (0, ALTURA-50, LARGURA, 50))
        pygame.draw.polygon(tela, self.cor_montanhas, [
            (0, ALTURA-50), (300, ALTURA-250), (600, ALTURA-50)
        ])

# Inicialização do jogo
jogador = Jogador()
inimigos = []
pontos = 0
vidas = 3
fonte = pygame.font.SysFont("Arial", 24, bold=True)
fonte_gameover = pygame.font.SysFont("Arial", 48, bold=True)
clock = pygame.time.Clock()
spawn_timer = 0
cenario = Cenario()
proxima_transformacao = 100

# Loop principal
rodando = True
while rodando:
    dt = clock.tick(60) / 1000

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            rodando = False
        elif event.type == pygame.KEYDOWN:
            # Disparo apenas com WASD
            if event.key == pygame.K_w:
                jogador.atirar_shuriken("cima")
            elif event.key == pygame.K_s:
                jogador.atirar_shuriken("baixo")
            elif event.key == pygame.K_a:
                jogador.atirar_shuriken("esquerda")
            elif event.key == pygame.K_d:
                jogador.atirar_shuriken("direita")

    # Movimento com SETAS e WASD
    teclas = pygame.key.get_pressed()
    jogador.mover(teclas)
    jogador.atualizar_transformacao()

    if pontos >= proxima_transformacao and not jogador.transformado:
        jogador.transformar()
        cenario.mudar_para_noite()
        proxima_transformacao += 100
    
    if jogador.transformado and jogador.tempo_transformacao <= 0:
        cenario.voltar_dia()

    spawn_timer += dt
    if spawn_timer >= 2.5 and len(inimigos) < 8:
        spawn_timer = 0
        inimigos.append(InimigoNinja())

    for shuriken in jogador.shurikens[:]:
        shuriken['x'] += shuriken['velx']
        shuriken['y'] += shuriken['vely']
        shuriken['frame'] += 1

        if (shuriken['x'] < 0 or shuriken['x'] > LARGURA or 
            shuriken['y'] < 0 or shuriken['y'] > ALTURA):
            jogador.shurikens.remove(shuriken)

    inimigos_para_remover = []

    for inimigo in inimigos:
        inimigo.mover(jogador.x, jogador.y)

        for shuriken in jogador.shurikens[:]:
            distancia = sqrt((shuriken['x']-inimigo.x)**2 + (shuriken['y']-inimigo.y)**2)
            if distancia < 15 + inimigo.tamanho:
                if shuriken in jogador.shurikens:
                    jogador.shurikens.remove(shuriken)
                inimigo.vida -= 1
                if inimigo.vida <= 0 and not inimigo.removido:
                    inimigos_para_remover.append(inimigo)
                    inimigo.removido = True
                    pontos += 10
                break

        distancia_jogador = sqrt((jogador.x-inimigo.x)**2 + (jogador.y-inimigo.y)**2)
        if distancia_jogador < (50 if jogador.transformado else 25) + inimigo.tamanho:
            if jogador.transformado and not inimigo.removido:
                inimigos_para_remover.append(inimigo)
                inimigo.removido = True
                pontos += 5
            elif not jogador.transformado and not inimigo.removido:
                inimigos_para_remover.append(inimigo)
                inimigo.removido = True
                vidas -= 1
                if vidas <= 0:
                    rodando = False

    for inimigo in inimigos_para_remover:
        if inimigo in inimigos:
            inimigos.remove(inimigo)

    if jogador.cooldown > 0:
        jogador.cooldown -= 1

    tela.fill(PRETO)
    cenario.desenhar()

    for shuriken in jogador.shurikens:
        pontos_shuriken = []
        for i in range(4):
            ang = radians(shuriken['frame'] * 45 + i * 90)
            pontos_shuriken.append((
                shuriken['x'] + 8 * cos(ang),
                shuriken['y'] + 8 * sin(ang)
            ))
        pygame.draw.polygon(tela, CINZA, pontos_shuriken)

    for inimigo in inimigos:
        inimigo.desenhar()

    jogador.desenhar()

    texto_pontos = fonte.render(f"Pontos: {pontos}", True, BRANCO)
    texto_vidas = fonte.render(f"Vidas: {vidas}", True, BRANCO)
    texto_transformacao = fonte.render(f"Próxima Transformação: {proxima_transformacao - pontos}", True, AMARELO)
    
    tela.blit(texto_pontos, (10, 10))
    tela.blit(texto_vidas, (10, 40))
    tela.blit(texto_transformacao, (10, 70))

    if jogador.transformado:
        tempo_restante = max(0, jogador.tempo_transformacao // 60)
        texto_poder = fonte_gameover.render(f"PODER ATIVO: {tempo_restante}s", True, VERMELHO_BRILHANTE)
        tela.blit(texto_poder, (LARGURA//2 - texto_poder.get_width()//2, 20))

    pygame.display.flip()

if vidas <= 0:
    tela.fill(PRETO)
    texto_gameover = fonte_gameover.render("GAME OVER", True, VERMELHO)
    texto_pontuacao = fonte.render(f"Pontuação Final: {pontos}", True, BRANCO)
    
    tela.blit(texto_gameover, (LARGURA//2 - texto_gameover.get_width()//2, ALTURA//2 - 50))
    tela.blit(texto_pontuacao, (LARGURA//2 - texto_pontuacao.get_width()//2, ALTURA//2 + 20))
    
    pygame.display.flip()
    pygame.time.wait(3000)

pygame.quit()
sys.exit()